/////////////////////////////////////////////////////////////////////////////
//    License (GPLv2+):
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful, but
//    WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//    General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
/////////////////////////////////////////////////////////////////////////////
/** 
 * @file  AboutDlg.cpp
 *
 * @brief Implementation of the About-dialog.
 *
 */
// RCS ID line follows -- this is updated by CVS
// $Id: AboutDlg.cpp 3351 2006-07-04 18:22:47Z kimmov $

#include "stdafx.h"
#include "Merge.h"
#include "AboutDlg.h"
#include "version.h"
#include "paths.h"
#include "coretools.h"


// URL for hyperlink in About-dialog
static const TCHAR WinMergeURL[] = _T("http://winmerge.org");

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_OPEN_CONTRIBUTORS, OnBnClickedOpenContributors)
END_MESSAGE_MAP()

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_COMPANY, m_ctlCompany);
	DDX_Control(pDX, IDC_WWW, m_ctlWWW);
	DDX_Text(pDX, IDC_VERSION, m_strVersion);
	DDX_Text(pDX, IDC_PRIVATEBUILD, m_strPrivateBuild);
	//}}AFX_DATA_MAP
}

/** 
 * @brief Read version info from resource to dialog.
 */
BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CMergeApp *pApp = dynamic_cast<CMergeApp *> (AfxGetApp());
	WORD langId = pApp->GetLangId();
	
	CVersionInfo version(langId);
	CString sVersion = version.GetFixedProductVersion();
	AfxFormatString1(m_strVersion, IDS_VERSION_FMT, sVersion);

#ifdef _UNICODE
	CString strUnicode;
	VERIFY(strUnicode.LoadString(IDS_UNICODE));
	m_strVersion += _T(" ");
	m_strVersion += strUnicode;
#endif

	CString sPrivateBuild = version.GetPrivateBuild();
	if (!sPrivateBuild.IsEmpty())
	{
		AfxFormatString1(m_strPrivateBuild, IDS_PRIVATEBUILD_FMT, sPrivateBuild);
	}

	CString copyright = version.GetLegalCopyright();

//VL: 2006-11-20 
    // My version info
    copyright += "\r\n\r\n";
    copyright += "VL /";
    copyright += CString(__DATE__);//.Replace("  ", " ");
    copyright += "/\r\n";

    // see also IDR_MAINFRAME "WinMergeVL..."
//VL: 2019-03-04 -Db1:2 - WinMerge date cut
    copyright += "2019-03-04 :: WinMergeVL19a01\n";
    copyright += " - Cutoff as ISO time\n";
//VL: 2015-09-09 -L5jd
    copyright += "2015-09-16 :: WinMergeVL15a07\n";
    copyright += " - xv/Temp\n";
    copyright += "2015-09-09 :: WinMergeVL15a06\n";
    copyright += " - word break at any punct(ch)\n";
    copyright += " - strike out identical\n";
    copyright += " - highlight after /bdate1:2015-01-02_12:30 /bdate2:...\n";
//VL: 2014-09-24 -U3
    copyright += "2014-09-24 :: WinMergeVL14a05\n";
    copyright += " - Alt-Insert copy whole text left to right\n";
    copyright += " - command line (UniPack) dir compare with recursion\n";
    copyright += " - file list: color by file ext\n";
    copyright += " - file list: left/right only icon bright color\n";
    copyright += " - ini config in UniPersonal, no registry\n";
    copyright += " - /escclosemain: ESC closes main window too\n";
    copyright += " - c:\\xv\\tmp\\WinMergeBak\\*.bak\n";
    copyright += " - splash disabled completely\n";
//VL.
    copyright += "2006:\n";
    copyright += " - Only close MergeView with Esc, not DirView\n";
//VL.

	m_ctlCompany.SetWindowText(copyright);
	m_ctlWWW.m_link = WinMergeURL;

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/** @brief Open Contributors.rtf */
void CAboutDlg::OnBnClickedOpenContributors()
{
	CString defPath = GetModulePath();
	// Don't add quotation marks yet, CFile doesn't like them
	CString docPath = defPath + _T("\\contributors.txt");
	HINSTANCE ret = 0;
	
	if (paths_DoesPathExist(docPath) == IS_EXISTING_FILE)
	{
		// Now, add quotation marks so ShellExecute() doesn't fail if path
		// includes spaces
		docPath.Insert(0, _T("\""));
		docPath.Insert(docPath.GetLength(), _T("\""));
		ret = ShellExecute(m_hWnd, NULL, _T("notepad"), docPath, defPath, SW_SHOWNORMAL);

		// values < 32 are errors (ref to MSDN)
		if ((int)ret < 32)
		{
			// Try to open with associated application (.txt)
			ret = ShellExecute(m_hWnd, _T("open"), docPath, NULL, NULL, SW_SHOWNORMAL);
			if ((int)ret < 32)
				ResMsgBox1(IDS_ERROR_EXECUTE_FILE, _T("Notepad.exe"), MB_ICONSTOP);
		}
	}
	else
		ResMsgBox1(IDS_ERROR_FILE_NOT_FOUND, docPath, MB_ICONSTOP);
}



#ifndef WindowStyle_h_included
#define WindowStyle_h_included

void WindowStyle_Add(CWnd * pwnd, DWORD newStyle);

#endif // WindowStyle_h_included

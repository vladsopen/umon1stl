#ifndef __EDTLIB_H
#define __EDTLIB_H

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000



#include "crystalparser.h"
#include "ccrystaltextbuffer.h"
#include "ccrystaltextview.h"
#include "ccrystaleditview.h"
#include "crystaleditviewex.h"

#endif // __EDTLIB_H

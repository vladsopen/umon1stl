#ifndef dlgutil_h_included
#define dlgutil_h_included

void dlgutil_SetMainIcon(CDialog * dlg);
void dlgutil_CenterToMainFrame(CDialog * dlg);

#endif // dlgutil_h_included

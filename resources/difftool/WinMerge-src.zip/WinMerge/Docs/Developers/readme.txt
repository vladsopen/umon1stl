2005-09-22
 Old history from 2005-04-04 through 2005-09-22.
 See Changes.txt for more up-to-date information.

2005-09-22 Kimmo
 New file Changes.txt created.
 See Changes.txt for more up-to-date information.

2005-08-28 Kimmo
 PATCH: [ 1274509 ] Small update for installer doc
  Developers: readme-developers-InnoSetup.html

2005-07-20 Tim
 PATCH: [ 1238450 ] Build script for manual at SF.net
  Developers: readme-manual.html

2005-06-02 Tim
 RFE: [ 1017179 ] Plugin readme's as HTML?
  Developers: new file Plugins.html

2005-05-11 Kimmo
 Options are now initialized in CMainFrame::OptionsInit() in OptionsInit.cpp
  Developers: Options.html

2005-04-17 Tim
 BUG: [ 1182013 ] Translation instructions don't mention installer or readme
  Developers: readme-developers.html

2005-04-05 Tim
 RFE: [ 1172479 ] Clarify bugfix-releases don't need translating
  Developers: readme-developers.html

2005-04-04 Tim
 RFE: [ 1061015 ] Offline build system for manual
  Developers: readme-developers.html new file readme-manual.html
 PATCH: [ 1176065 ] New heading style for developers docs
  Developers: *.html

WINMERGE

WinMerge �r ett Open Source Filj�mf�relse och Mergeprogram som fungerar p�
alla moderna Windowsversioner. N�gra funktioner kr�ver ytterligare 
installationer eller komponenter.

Senaste versionen av WinMerge och annan WinMerge information finns p�
http://www.winmerge.org

Snabbstart f�r WinMerge (Quick start to WinMerge):
L�s online-manualens Quick start-kapitel f�r att starta med WinMerge:
http://www.winmerge.org/2.4/manual/quickstart.html

HTML Manual:
Manual finns tillg�ngling online p�
http://www.winmerge.org/2.4/manual/
det �r ocks� m�jligtvis installerat (om detta �r valt) lokalt och 
nerladdningsbart separat fr�n http://www.winmerge.org/ (se dokumentation).

Arkivst�d (Archive Support):
WinMerge anv�nder 7-Zip f�r arkivfilst�d. 7-Zip (http://www.7-zip.org)
�r ett Open Source arkivprogram. F�r att installera arkivst�d , ladda ner
7-Zip plugininstalleraren fr�n http://www.winmerge.org/.

Installera arkivst�d (Installing archive support):
Det �r rekommenderat att installera 7-Zip programmet. Om detta inte kan g�ras av
n�gon anledning, kan 7-zip plugininstalleraren installera bara kr�vda filer f�r
att st�dja arkivfilst�d. Notera att detta INTE till�ter sj�lvst�ndigt anv�ndande 
av 7-Zip utan att det bara ger arkivst�d f�r WinMerge.

Skript-support (Script Support):
Om du vill arbeta med skript m�ste du ha Windows
Script Host ('wscript.exe') installerat. Om du f�r fel relaterade till dina
skript var god och bes�k
http://msdn.microsoft.com/library/default.asp?url=/downloads/list/webdev.asp
f�r att vara s�ker p� att din Windows Script Host �r b�de uppdaterad och inte
trasig.

Support:
Utvecklare besvarar fr�gor i Sourceforge.nets WinMerge forum:
http://sourceforge.net/forum/?group_id=13216

Fel och funktionsf�rfr�gningar (Bugs and feature requests):
Fel och f�rslag p� nya funktioner ska skickas till Felsp�rare (Bug tracker) och 
Funktionsbeg�ranssp�rare (RFE) p� sourceforge.net

Felsp�rare (Bug tracker):
http://sourceforge.net/tracker/?group_id=13216&atid=113216
N�r du rapporterar ett fel, var god och tala om f�r oss WinMerges versionsnummer!
WinMerge-versionerna 2.2.0 och senare kan producera 'WinMerge Configuration Log'
fr�n menyn Hj�lp/Konfiguration. Var god och bifoga denna information 
(som en bifogad fil) till felrapporten, d� den har mycket anv�ndbar information
f�r utvecklare.

Funktionsbeg�ranssp�rare (RFE):
http://sourceforge.net/tracker/?group_id=13216&atid=363216


WinMerges utvecklare

#ifndef ByteMapping_h_included
#define ByteMapping_h_included

class ByteMapping
{
public:
	int Map(unsigned char byte, unsigned char * output);

// Implementation data
private:

};

#endif // ByteMapping_h_included
